package entity;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import main.Gamepanel;
import main.KeyHandler;

public class Player extends entity {

    Gamepanel gp;
    KeyHandler keyH;

    public final int screenX;
    public final int screenY;

    boolean isIdle = true; // Add this variable

    private Clip walkSound; // Sound for walking
    private boolean isWalking = false;

    public Player(Gamepanel gp, KeyHandler keyH) {
        this.gp = gp;
        this.keyH = keyH;

        screenX = gp.screenWidth / 2 - (gp.tileSize / 2);
        screenY = gp.screenHeight / 2 - (gp.tileSize / 2);

        solidArea = new Rectangle();
        solidArea.x = 8;
        solidArea.y = 16;
        solidArea.width = 32;
        solidArea.height = 32;

        setDefaultValues();
        getPlayerImage();
        loadSound();
    }

    public void loadSound() {
        try {
            InputStream audioSrc = getClass().getResourceAsStream("/sound/footstep.wav");
            InputStream bufferedIn = new BufferedInputStream(audioSrc);
            AudioInputStream ais = AudioSystem.getAudioInputStream(bufferedIn);
            walkSound = AudioSystem.getClip();
            walkSound.open(ais);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setDefaultValues() {
        // player position
        worldX = gp.tileSize * 23;
        worldY = gp.tileSize * 21;
        speed = 4;
        Direction = "down";

    }

    public void getPlayerImage() {
        try {
            up1 = ImageIO.read(getClass().getResourceAsStream("/player/backfacingRightfoot.png"));
            upId = ImageIO.read(getClass().getResourceAsStream("/player/backfacingIdle.png"));
            up2 = ImageIO.read(getClass().getResourceAsStream("/player/backRighthand.png"));
            left1 = ImageIO.read(getClass().getResourceAsStream("/player/leftfacingLeftfoot.png"));
            leftId = ImageIO.read(getClass().getResourceAsStream("/player/leftFacingIdle.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("/player/leftFacingRightfoot.png"));
            down1 = ImageIO.read(getClass().getResourceAsStream("/player/frontLeftfoot.png"));
            downId = ImageIO.read(getClass().getResourceAsStream("/player/frontIdle.png"));
            down2 = ImageIO.read(getClass().getResourceAsStream("/player/frontRightfoot.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("/player/rightfacingLeftfoot.png"));
            rightId = ImageIO.read(getClass().getResourceAsStream("/player/rightfacingIdle.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/player/rightfacingRightfoot.png"));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void update() {
        boolean isMoving = keyH.upPressed || keyH.downPressed || keyH.leftPressed || keyH.rightPressed;

        if (isMoving) {
            if (keyH.upPressed) {
                Direction = "up";

            } else if (keyH.downPressed) {
                Direction = "down";

            } else if (keyH.leftPressed) {
                Direction = "left";

            } else if (keyH.rightPressed) {
                Direction = "right";

            }

            // check tile collision
            collisionOn = false;
            gp.cChecker.checkTile(this);
            
            //CHECK OBJECT COLLISION
            int objIndex = gp.cChecker.checkObject(this, true);

            // if collision if false, player can move
            if (collisionOn == false) {
                switch (Direction) {
                    case "up":
                        worldY -= speed;
                        break;

                    case "down":
                        worldY += speed;
                        break;

                    case "left":
                        worldX -= speed;
                        break;

                    case "right":
                        worldX += speed;
                        break;
                }
                if (!isWalking) {
                    walkSound.start();
                    walkSound.loop(Clip.LOOP_CONTINUOUSLY);
                    isWalking = true;
                }
            }

            spriteCounter++;
            if (spriteCounter > 13) {
                spriteNum++;
                if (spriteNum > 4) {
                    spriteNum = 1;
                }
                spriteCounter = 0;
                isIdle = false; // Player is not idle anymore
            }
        } else {
            if (Direction.equals("up")) {
                Direction = "idle_up";
            } else if (Direction.equals("down")) {
                Direction = "idle_down";
            } else if (Direction.equals("left")) {
                Direction = "idle_left";
            } else if (Direction.equals("right")) {
                Direction = "idle_right";
            }

            if (!isIdle) { // Reset sprite cycle only if player was moving
                spriteCounter = 0;
                spriteNum = 1;
                isIdle = true;
                walkSound.stop();
                isWalking = false;
            } else {
                spriteCounter++;
                if (spriteCounter > 13) {
                    spriteNum++;
                    if (spriteNum > 4) {
                        spriteNum = 1;
                    }
                    spriteCounter = 0;
                }
            }
        }
    }

    public void draw(Graphics2D g2) {
        BufferedImage image = null;
        switch (Direction) {
            case "up":
                if (spriteNum == 1) {
                    image = up1;
                } else if (spriteNum == 2) {
                    image = upId;
                } else if (spriteNum == 3) {
                    image = up2;
                } else if (spriteNum == 4) {
                    image = upId;
                }
                break;

            case "down":
                if (spriteNum == 1) {
                    image = down1;
                } else if (spriteNum == 2) {
                    image = downId;
                } else if (spriteNum == 3) {
                    image = down2;
                } else if (spriteNum == 4) {
                    image = downId;
                }
                break;

            case "left":
                if (spriteNum == 1) {
                    image = left1;
                } else if (spriteNum == 2) {
                    image = leftId;
                } else if (spriteNum == 3) {
                    image = left2;
                } else if (spriteNum == 4) {
                    image = leftId;
                }
                break;

            case "right":
                if (spriteNum == 1) {
                    image = right1;
                } else if (spriteNum == 2) {
                    image = rightId;
                } else if (spriteNum == 3) {
                    image = right2;
                } else if (spriteNum == 4) {
                    image = rightId;
                }
                break;

            case "idle_up":
                image = upId;
                break;

            case "idle_down":
                image = downId;
                break;

            case "idle_left":
                image = leftId;
                break;

            case "idle_right":
                image = rightId;
                break;
        }
        g2.drawImage(image, screenX, screenY, gp.tileSize, gp.tileSize, null);
    }
}
