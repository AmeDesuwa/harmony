package entity;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class entity {
	
	public int worldX,worldY;
	public int speed;
	
	public BufferedImage up1, upId, up2, down1, downId, down2, left1, leftId, left2, right1, rightId, right2;
	public String Direction;
	
	public int spriteCounter = 0;
	public int spriteNum = 1;
	
	public Rectangle solidArea;
	public int solidAreaDefaultX, solidAreaDefaultY;
	public boolean collisionOn = false;
}
